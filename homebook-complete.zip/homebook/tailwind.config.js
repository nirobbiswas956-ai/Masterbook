export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        homebook: {
          blue: "#1877F2",
          darkBlue: "#0D5BD7",
          yellow: "#F4C430",
          background: "#F0F2F5"
        }
      }
    }
  },
  plugins: []
};