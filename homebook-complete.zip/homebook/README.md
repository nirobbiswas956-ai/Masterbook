# HOMEBOOK

Homebook is a mobile-first social web app built with React, TypeScript, Vite, Tailwind CSS and Firebase.

## Included in this starter

- Firebase email/password authentication
- User profiles
- Profile avatar and cover uploads
- Text posts
- Likes/comments/shares
- Follow/friend foundation
- Notifications
- Real-time Messenger
- Direct conversations
- Group conversation foundation
- Typing indicator
- Online/last-active foundation
- Delivered/read status
- Message reactions
- Reply/forward foundation
- Image/file messages
- Mute/archive/pin conversation foundation
- Firestore and Storage security rules

## Setup

1. Install Node.js.
2. Run `npm install`.
3. Copy `.env.example` to `.env`.
4. Put your Firebase Web App configuration into `.env`.
5. In Firebase Console enable:
   - Authentication -> Email/Password
   - Firestore Database
   - Storage
6. Publish `firestore.rules`.
7. Publish `storage.rules`.
8. Run:

```bash
npm run dev
```

## Build

```bash
npm run build
```

## Important

This is the current application foundation, not the final production-complete Homebook specification.

Still to be added/hardened:
- Cloud Functions for trusted notification creation
- FCM web push
- phone authentication and verification
- 2FA
- Stories
- Reels/short video system
- advanced media processing
- voice messages
- WebRTC voice/video calls with signaling and STUN/TURN
- full group management UI
- moderation/admin dashboard
- App Check
- rate limiting
- server-side validation
- production-grade idempotency and transaction handling
- tests and Emulator Suite
- PWA/offline improvements
- data export/deletion workflow
