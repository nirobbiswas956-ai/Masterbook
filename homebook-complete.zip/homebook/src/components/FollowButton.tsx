import { useEffect, useState } from "react";
import {
  followUser,
  isFollowing,
  unfollowUser
} from "../services/social";

export default function FollowButton({
  myUid,
  targetUid
}: {
  myUid: string;
  targetUid: string;
}) {
  const [following, setFollowing] =
    useState(false);
  const [loading, setLoading] =
    useState(false);

  useEffect(() => {
    isFollowing(
      myUid,
      targetUid
    ).then(setFollowing);
  }, [myUid, targetUid]);

  async function toggle() {
    try {
      setLoading(true);

      if (following) {
        await unfollowUser(
          myUid,
          targetUid
        );
        setFollowing(false);
      } else {
        await followUser(
          myUid,
          targetUid
        );
        setFollowing(true);
      }
    } finally {
      setLoading(false);
    }
  }

  return (
    <button
      onClick={toggle}
      disabled={loading}
      className="rounded-xl bg-blue-600 px-3 py-2 text-xs font-bold text-white disabled:opacity-50"
    >
      {following
        ? "Following"
        : "Follow"}
    </button>
  );
}