import { useEffect, useState } from "react";
import { User } from "firebase/auth";
import {
  Camera,
  Save
} from "lucide-react";
import {
  getUserProfile,
  updateUserProfile
} from "../services/profile";
import {
  uploadProfileImage
} from "../services/storage";

export default function ProfilePage({
  user
}: {
  user: User;
}) {
  const [profile, setProfile] =
    useState<any>(null);

  const [fullName, setFullName] =
    useState("");

  const [username, setUsername] =
    useState("");

  const [bio, setBio] =
    useState("");

  const [saving, setSaving] =
    useState(false);

  useEffect(() => {
    getUserProfile(user.uid)
      .then(data => {
        setProfile(data);
        setFullName(data?.fullName || "");
        setUsername(data?.username || "");
        setBio(data?.bio || "");
      })
      .catch(console.error);
  }, [user.uid]);

  async function save() {
    try {
      setSaving(true);

      await updateUserProfile(
        user.uid,
        {
          fullName: fullName.trim(),
          username: username
            .trim()
            .toLowerCase()
            .replace(/[^a-z0-9_]/g, ""),
          bio: bio.trim()
        }
      );

      alert("Profile updated.");
    } catch (error: any) {
      alert(
        error?.message ||
        "Could not update profile."
      );
    } finally {
      setSaving(false);
    }
  }

  async function upload(
    file: File,
    type: "avatar" | "cover"
  ) {
    try {
      const url =
        await uploadProfileImage(
          user.uid,
          file,
          type
        );

      await updateUserProfile(
        user.uid,
        type === "avatar"
          ? { photoURL: url }
          : { coverURL: url }
      );

      setProfile({
        ...profile,
        ...(type === "avatar"
          ? { photoURL: url }
          : { coverURL: url })
      });
    } catch (error: any) {
      alert(
        error?.message ||
        "Upload failed."
      );
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-3 py-5 pb-24">
      <div className="overflow-hidden rounded-2xl bg-white shadow-sm dark:bg-gray-900">

        <div className="relative h-44 bg-blue-100 dark:bg-blue-950">
          {profile?.coverURL && (
            <img
              src={profile.coverURL}
              alt=""
              className="h-full w-full object-cover"
            />
          )}

          <label className="absolute right-4 top-4 cursor-pointer rounded-xl bg-white/90 p-3 shadow">
            <Camera size={20} />
            <input
              type="file"
              hidden
              accept="image/jpeg,image/png,image/webp"
              onChange={e => {
                const file =
                  e.target.files?.[0];
                if (file) {
                  upload(file, "cover");
                }
              }}
            />
          </label>
        </div>

        <div className="p-5">
          <div className="-mt-16 mb-5">
            {profile?.photoURL ? (
              <img
                src={profile.photoURL}
                alt=""
                className="h-28 w-28 rounded-full border-4 border-white object-cover shadow"
              />
            ) : (
              <div className="flex h-28 w-28 items-center justify-center rounded-full border-4 border-white bg-blue-100 text-3xl font-black text-blue-600 shadow">
                {fullName.charAt(0)}
              </div>
            )}

            <label className="mt-2 inline-flex cursor-pointer items-center gap-2 rounded-xl bg-blue-50 px-3 py-2 text-sm font-bold text-blue-600">
              <Camera size={16} />
              Change photo
              <input
                type="file"
                hidden
                accept="image/jpeg,image/png,image/webp"
                onChange={e => {
                  const file =
                    e.target.files?.[0];
                  if (file) {
                    upload(file, "avatar");
                  }
                }}
              />
            </label>
          </div>

          <div className="space-y-3">
            <input
              value={fullName}
              maxLength={80}
              onChange={e =>
                setFullName(e.target.value)
              }
              placeholder="Full name"
              className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none dark:bg-gray-800"
            />

            <input
              value={username}
              maxLength={30}
              onChange={e =>
                setUsername(e.target.value)
              }
              placeholder="Username"
              className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none dark:bg-gray-800"
            />

            <textarea
              value={bio}
              maxLength={300}
              onChange={e =>
                setBio(e.target.value)
              }
              placeholder="Bio"
              className="min-h-28 w-full resize-none rounded-xl bg-gray-100 p-4 outline-none dark:bg-gray-800"
            />

            <button
              onClick={save}
              disabled={saving}
              className="flex w-full items-center justify-center gap-2 rounded-xl bg-blue-600 py-3 font-bold text-white disabled:opacity-50"
            >
              <Save size={18} />
              {saving
                ? "Saving..."
                : "Save profile"}
            </button>
          </div>
        </div>

      </div>
    </main>
  );
}