import { FormEvent, useState } from "react";
import { loginUser, registerUser } from "../services/auth";

export default function AuthScreen() {
  const [signup, setSignup] = useState(false);
  const [fullName, setFullName] = useState("");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");

    if (signup && password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    try {
      setLoading(true);

      if (signup) {
        await registerUser(
          fullName,
          username,
          email,
          password
        );
      } else {
        await loginUser(email, password);
      }
    } catch (err: any) {
      setError(
        err?.message ||
        "Something went wrong."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[#f0f2f5] px-4">
      <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-lg">
        <img
          src="/logo.svg"
          alt="Homebook"
          className="mx-auto h-20 w-20"
        />

        <h1 className="mt-4 text-center text-3xl font-black text-blue-600">
          Homebook
        </h1>

        <p className="mt-2 text-center text-gray-500">
          Connect • Share • Grow
        </p>

        {error && (
          <div className="mt-4 rounded-xl bg-red-50 p-3 text-sm text-red-600">
            {error}
          </div>
        )}

        <form
          onSubmit={submit}
          className="mt-5 space-y-3"
        >
          {signup && (
            <>
              <input
                value={fullName}
                onChange={e =>
                  setFullName(e.target.value)
                }
                placeholder="Full name"
                className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none"
              />

              <input
                value={username}
                onChange={e =>
                  setUsername(e.target.value)
                }
                placeholder="Username"
                className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none"
              />
            </>
          )}

          <input
            type="email"
            value={email}
            onChange={e =>
              setEmail(e.target.value)
            }
            placeholder="Email"
            className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none"
          />

          <input
            type="password"
            value={password}
            onChange={e =>
              setPassword(e.target.value)
            }
            placeholder="Password"
            className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none"
          />

          {signup && (
            <input
              type="password"
              value={confirm}
              onChange={e =>
                setConfirm(e.target.value)
              }
              placeholder="Confirm password"
              className="w-full rounded-xl bg-gray-100 px-4 py-3 outline-none"
            />
          )}

          <button
            disabled={loading}
            className="w-full rounded-xl bg-blue-600 py-3 font-bold text-white disabled:opacity-50"
          >
            {loading
              ? "Please wait..."
              : signup
                ? "Create account"
                : "Login"}
          </button>
        </form>

        <button
          onClick={() => {
            setSignup(!signup);
            setError("");
          }}
          className="mt-4 w-full text-sm font-bold text-blue-600"
        >
          {signup
            ? "Already have an account? Login"
            : "Create a new account"}
        </button>
      </div>
    </div>
  );
}