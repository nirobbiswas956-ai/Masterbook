import {
  FormEvent,
  useEffect,
  useRef,
  useState
} from "react";

import {
  Archive,
  ArrowLeft,
  Check,
  CheckCheck,
  File,
  Image as ImageIcon,
  MessageCircle,
  MoreVertical,
  Pin,
  PinOff,
  Reply,
  Search,
  Send,
  Smile,
  Trash2,
  UserRound,
  Users,
  Volume2,
  VolumeX,
  X
} from "lucide-react";

import { User } from "firebase/auth";

import { uploadMessageFile } from "../services/storage";

import {
  createDirectConversation,
  createGroupConversation,
  deleteMessage,
  editMessage,
  listenMessages,
  listenMyConversations,
  listenPresence,
  listenTyping,
  markMessageDelivered,
  markMessageRead,
  reactToMessage,
  searchMessengerUsers,
  sendMessage,
  setTyping,
  updatePresence,
  clearUnread,
  toggleArchiveConversation,
  toggleMuteConversation,
  togglePinConversation
} from "../services/messenger";

const EMOJIS = [
  "👍",
  "❤️",
  "😂",
  "😮",
  "😢",
  "😡",
  "🙏",
  "🔥"
];

export default function MessengerPage({
  user
}: {
  user: User;
}) {
  const [conversations, setConversations] =
    useState<any[]>([]);
  const [activeConversation, setActiveConversation] =
    useState<any | null>(null);
  const [messages, setMessages] =
    useState<any[]>([]);
  const [text, setText] = useState("");
  const [searchText, setSearchText] =
    useState("");
  const [searchResults, setSearchResults] =
    useState<any[]>([]);
  const [typing, setTypingState] =
    useState(false);
  const [otherOnline, setOtherOnline] =
    useState(false);
  const [otherLastActive, setOtherLastActive] =
    useState<any>(null);
  const [replyMessage, setReplyMessage] =
    useState<any | null>(null);
  const [menuMessage, setMenuMessage] =
    useState<string | null>(null);
  const [showEmoji, setShowEmoji] =
    useState(false);
  const [showMenu, setShowMenu] =
    useState(false);
  const [loading, setLoading] =
    useState(false);
  const [editingMessage, setEditingMessage] =
    useState<any | null>(null);

  const fileInputRef =
    useRef<HTMLInputElement>(null);

  const typingTimer =
    useRef<ReturnType<typeof setTimeout> | null>(
      null
    );

  useEffect(() => {
    updatePresence(user.uid, true);

    const visibility = () => {
      updatePresence(
        user.uid,
        document.visibilityState === "visible"
      );
    };

    document.addEventListener(
      "visibilitychange",
      visibility
    );

    return () => {
      updatePresence(user.uid, false);
      document.removeEventListener(
        "visibilitychange",
        visibility
      );
    };
  }, [user.uid]);

  useEffect(() => {
    return listenMyConversations(
      user.uid,
      setConversations
    );
  }, [user.uid]);

  useEffect(() => {
    if (!activeConversation) {
      setMessages([]);
      return;
    }

    return listenMessages(
      activeConversation.id,
      setMessages
    );
  }, [activeConversation]);

  const otherUid =
    activeConversation?.memberIds?.find(
      (id: string) =>
        id !== user.uid
    ) || "";

  useEffect(() => {
    if (!otherUid) return;

    return listenPresence(
      otherUid,
      data => {
        setOtherOnline(
          data.online === true
        );
        setOtherLastActive(
          data.lastActive
        );
      }
    );
  }, [otherUid]);

  useEffect(() => {
    if (!activeConversation || !otherUid) {
      return;
    }

    return listenTyping(
      activeConversation.id,
      otherUid,
      setTypingState
    );
  }, [activeConversation, otherUid]);

  useEffect(() => {
    if (!activeConversation) return;

    clearUnread(
      activeConversation.id,
      user.uid
    ).catch(console.error);

    messages.forEach(message => {
      if (message.senderId !== user.uid) {
        markMessageDelivered(
          activeConversation.id,
          message.id,
          user.uid
        ).catch(console.error);

        markMessageRead(
          activeConversation.id,
          message.id,
          user.uid
        ).catch(console.error);
      }
    });
  }, [
    messages,
    activeConversation,
    user.uid
  ]);

  async function searchUsers(
    value: string
  ) {
    setSearchText(value);

    if (!value.trim()) {
      setSearchResults([]);
      return;
    }

    try {
      const result =
        await searchMessengerUsers(value);

      setSearchResults(
        result.filter(
          item => item.id !== user.uid
        )
      );
    } catch (error) {
      console.error(error);
    }
  }

  async function startDirectChat(
    targetUid: string
  ) {
    try {
      setLoading(true);

      const id =
        await createDirectConversation(
          user.uid,
          targetUid
        );

      const existing =
        conversations.find(
          item => item.id === id
        );

      setActiveConversation(
        existing || {
          id,
          type: "direct",
          memberIds: [
            user.uid,
            targetUid
          ]
        }
      );

      setSearchText("");
      setSearchResults([]);
    } catch (error: any) {
      alert(
        error?.message ||
        "Could not open chat."
      );
    } finally {
      setLoading(false);
    }
  }

  async function createGroup() {
    const name =
      window.prompt("Group name");

    if (!name) return;

    const ids =
      window.prompt(
        "Enter member UIDs separated by commas"
      );

    if (!ids) return;

    const memberIds =
      ids
        .split(",")
        .map(id => id.trim())
        .filter(Boolean);

    try {
      setLoading(true);

      const id =
        await createGroupConversation(
          user.uid,
          memberIds,
          name
        );

      setActiveConversation({
        id,
        type: "group",
        name,
        memberIds: [
          user.uid,
          ...memberIds
        ]
      });
    } catch (error: any) {
      alert(
        error?.message ||
        "Could not create group."
      );
    } finally {
      setLoading(false);
    }
  }

  async function handleSend(
    event: FormEvent
  ) {
    event.preventDefault();

    if (!activeConversation) return;
    if (!text.trim()) return;

    try {
      if (editingMessage) {
        await editMessage(
          activeConversation.id,
          editingMessage.id,
          text
        );
        setEditingMessage(null);
      } else {
        await sendMessage(
          activeConversation.id,
          user.uid,
          text,
          replyMessage
            ? "reply"
            : "text",
          null,
          null,
          replyMessage
            ? {
                id: replyMessage.id,
                text: replyMessage.text,
                senderId:
                  replyMessage.senderId
              }
            : null
        );
      }

      setText("");
      setReplyMessage(null);

      await setTyping(
        activeConversation.id,
        user.uid,
        false
      );
    } catch (error: any) {
      alert(
        error?.message ||
        "Could not send message."
      );
    }
  }

  function handleTyping(value: string) {
    setText(value);

    if (!activeConversation) return;

    setTyping(
      activeConversation.id,
      user.uid,
      value.trim().length > 0
    ).catch(console.error);

    if (typingTimer.current) {
      clearTimeout(
        typingTimer.current
      );
    }

    typingTimer.current =
      setTimeout(() => {
        if (activeConversation) {
          setTyping(
            activeConversation.id,
            user.uid,
            false
          ).catch(console.error);
        }
      }, 1200);
  }

  async function handleFile(file: File) {
    if (!activeConversation) return;

    try {
      setLoading(true);

      const url =
        await uploadMessageFile(
          user.uid,
          activeConversation.id,
          file
        );

      const isImage =
        file.type.startsWith("image/");

      await sendMessage(
        activeConversation.id,
        user.uid,
        "",
        isImage
          ? "image"
          : "file",
        url,
        file.name
      );
    } catch (error: any) {
      alert(
        error?.message ||
        "Upload failed."
      );
    } finally {
      setLoading(false);
    }
  }

  async function handleReaction(
    messageId: string,
    emoji: string
  ) {
    if (!activeConversation) return;

    await reactToMessage(
      activeConversation.id,
      messageId,
      user.uid,
      emoji
    );

    setMenuMessage(null);
  }

  async function handleForward(
    message: any
  ) {
    const target =
      window.prompt(
        "Enter target conversation ID"
      );

    if (!target) return;

    try {
      await sendMessage(
        target,
        user.uid,
        message.text || "",
        "forward",
        message.fileURL || null,
        message.fileName || null,
        null,
        {
          id: message.id,
          senderId:
            message.senderId,
          text:
            message.text || ""
        }
      );

      alert("Message forwarded.");
    } catch (error: any) {
      alert(
        error?.message ||
        "Forward failed."
      );
    }
  }

  async function toggleMute() {
    if (!activeConversation) return;

    const current =
      activeConversation.membership
        ?.muted === true;

    await toggleMuteConversation(
      activeConversation.id,
      user.uid,
      !current
    );
  }

  async function toggleArchive() {
    if (!activeConversation) return;

    const current =
      activeConversation.membership
        ?.archived === true;

    await toggleArchiveConversation(
      activeConversation.id,
      user.uid,
      !current
    );
  }

  async function togglePin() {
    if (!activeConversation) return;

    const current =
      activeConversation.membership
        ?.pinned === true;

    await togglePinConversation(
      activeConversation.id,
      user.uid,
      !current
    );
  }

  function formatLastActive(timestamp: any) {
    if (!timestamp) return "Offline";

    const date =
      timestamp.toDate
        ? timestamp.toDate()
        : new Date(timestamp);

    return `Last active ${date.toLocaleString(
      "en-BD"
    )}`;
  }

  return (
    <main className="mx-auto max-w-6xl px-0 pb-20 sm:px-4 sm:py-5">
      <div className="flex h-[calc(100vh-110px)] min-h-[560px] overflow-hidden bg-white shadow-sm dark:bg-gray-900 sm:rounded-2xl">

        <aside
          className={`w-full border-r dark:border-gray-800 sm:w-80 ${
            activeConversation
              ? "hidden sm:block"
              : "block"
          }`}
        >
          <div className="border-b p-4 dark:border-gray-800">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageCircle
                  className="text-blue-600"
                  size={25}
                />
                <h1 className="text-xl font-black">
                  Messenger
                </h1>
              </div>

              <button
                onClick={createGroup}
                className="rounded-xl bg-blue-50 p-2 text-blue-600 dark:bg-blue-950"
              >
                <Users size={19} />
              </button>
            </div>

            <div className="relative mt-4">
              <Search
                className="absolute left-3 top-3.5 text-gray-400"
                size={18}
              />

              <input
                value={searchText}
                onChange={e =>
                  searchUsers(
                    e.target.value
                  )
                }
                placeholder="Search username..."
                className="w-full rounded-xl bg-gray-100 py-3 pl-10 pr-3 outline-none dark:bg-gray-800"
              />
            </div>

            {searchResults.length > 0 && (
              <div className="mt-2 overflow-hidden rounded-xl border bg-white shadow-lg dark:border-gray-700 dark:bg-gray-900">
                {searchResults.map(result => (
                  <button
                    key={result.id}
                    onClick={() =>
                      startDirectChat(
                        result.id
                      )
                    }
                    className="flex w-full items-center gap-3 p-3 text-left hover:bg-gray-50 dark:hover:bg-gray-800"
                  >
                    {result.photoURL ? (
                      <img
                        src={
                          result.photoURL
                        }
                        alt=""
                        className="h-10 w-10 rounded-full object-cover"
                      />
                    ) : (
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                        <UserRound
                          size={19}
                        />
                      </div>
                    )}

                    <div>
                      <p className="font-bold">
                        {result.fullName}
                      </p>
                      <p className="text-xs text-gray-500">
                        @{result.username}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div className="overflow-y-auto">
            {conversations.map(
              conversation => (
                <ConversationItem
                  key={conversation.id}
                  conversation={
                    conversation
                  }
                  targetUid={
                    conversation.memberIds?.find(
                      (id: string) =>
                        id !== user.uid
                    )
                  }
                  active={
                    activeConversation?.id ===
                    conversation.id
                  }
                  onClick={() =>
                    setActiveConversation(
                      conversation
                    )
                  }
                />
              )
            )}
          </div>
        </aside>

        <section
          className={`flex min-w-0 flex-1 flex-col ${
            activeConversation
              ? "flex"
              : "hidden sm:flex"
          }`}
        >
          {!activeConversation ? (
            <div className="flex flex-1 flex-col items-center justify-center text-center">
              <MessageCircle
                className="text-gray-300"
                size={70}
              />
              <h2 className="mt-4 text-xl font-bold">
                Your messages
              </h2>
              <p className="mt-2 text-gray-500">
                Search a user to start chatting.
              </p>
            </div>
          ) : (
            <>
              <header className="flex items-center gap-3 border-b p-3 dark:border-gray-800">
                <button
                  onClick={() =>
                    setActiveConversation(
                      null
                    )
                  }
                  className="rounded-full p-2 hover:bg-gray-100 dark:hover:bg-gray-800 sm:hidden"
                >
                  <ArrowLeft size={21} />
                </button>

                <div className="flex h-11 w-11 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900">
                  {activeConversation.type ===
                  "group" ? (
                    <Users size={22} />
                  ) : (
                    <UserRound
                      size={22}
                    />
                  )}
                </div>

                <div className="min-w-0 flex-1">
                  <p className="truncate font-bold">
                    {activeConversation.type ===
                    "group"
                      ? activeConversation.name
                      : otherUid}
                  </p>

                  <p className="text-xs text-gray-500">
                    {typing
                      ? "Typing..."
                      : activeConversation.type ===
                          "group"
                        ? `${activeConversation.memberIds?.length || 0} members`
                        : otherOnline
                          ? "Online"
                          : formatLastActive(
                              otherLastActive
                            )}
                  </p>
                </div>

                <div className="relative">
                  <button
                    onClick={() =>
                      setShowMenu(
                        !showMenu
                      )
                    }
                    className="rounded-full p-2 hover:bg-gray-100 dark:hover:bg-gray-800"
                  >
                    <MoreVertical
                      size={21}
                    />
                  </button>

                  {showMenu && (
                    <div className="absolute right-0 top-11 z-20 w-52 rounded-xl bg-white p-2 shadow-xl dark:bg-gray-800">
                      <button
                        onClick={() => {
                          toggleMute();
                          setShowMenu(false);
                        }}
                        className="flex w-full items-center gap-3 rounded-lg p-3 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
                      >
                        {activeConversation.membership?.muted ? (
                          <Volume2 size={18} />
                        ) : (
                          <VolumeX size={18} />
                        )}
                        {activeConversation.membership?.muted
                          ? "Unmute"
                          : "Mute"}
                      </button>

                      <button
                        onClick={() => {
                          toggleArchive();
                          setShowMenu(false);
                        }}
                        className="flex w-full items-center gap-3 rounded-lg p-3 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
                      >
                        <Archive size={18} />
                        Archive
                      </button>

                      <button
                        onClick={() => {
                          togglePin();
                          setShowMenu(false);
                        }}
                        className="flex w-full items-center gap-3 rounded-lg p-3 text-left hover:bg-gray-100 dark:hover:bg-gray-700"
                      >
                        {activeConversation.membership?.pinned ? (
                          <PinOff size={18} />
                        ) : (
                          <Pin size={18} />
                        )}
                        {activeConversation.membership?.pinned
                          ? "Unpin"
                          : "Pin"}
                      </button>
                    </div>
                  )}
                </div>
              </header>

              <div className="flex-1 space-y-3 overflow-y-auto bg-gray-50 p-4 dark:bg-gray-950">
                {messages.map(message => {
                  const mine =
                    message.senderId ===
                    user.uid;

                  const deleted =
                    message.type ===
                    "deleted";

                  const reactions =
                    message.reactions ||
                    {};

                  return (
                    <div
                      key={message.id}
                      className={`group flex ${
                        mine
                          ? "justify-end"
                          : "justify-start"
                      }`}
                    >
                      <div className="relative max-w-[82%]">
                        {message.replyTo && (
                          <div className="mb-1 rounded-lg border-l-4 border-blue-500 bg-blue-50 px-3 py-2 text-xs dark:bg-blue-950">
                            <p className="font-bold">
                              Reply
                            </p>
                            <p className="truncate">
                              {message.replyTo.text}
                            </p>
                          </div>
                        )}

                        {message.forwardedFrom && (
                          <p className="mb-1 text-xs font-bold text-gray-500">
                            ↗ Forwarded
                          </p>
                        )}

                        <div
                          className={`rounded-2xl px-4 py-3 ${
                            deleted
                              ? "italic text-gray-500"
                              : mine
                                ? "bg-blue-600 text-white"
                                : "bg-white shadow-sm dark:bg-gray-800"
                          }`}
                        >
                          {message.type ===
                            "image" &&
                            message.fileURL && (
                              <img
                                src={
                                  message.fileURL
                                }
                                alt={
                                  message.fileName ||
                                  "Image"
                                }
                                className="mb-2 max-h-72 rounded-xl"
                              />
                            )}

                          {message.type ===
                            "file" &&
                            message.fileURL && (
                              <a
                                href={
                                  message.fileURL
                                }
                                target="_blank"
                                rel="noreferrer"
                                className="mb-2 flex items-center gap-2 underline"
                              >
                                <File
                                  size={18}
                                />
                                {message.fileName}
                              </a>
                            )}

                          {message.text && (
                            <p className="break-words">
                              {message.text}
                            </p>
                          )}
                        </div>

                        {Object.entries(
                          reactions
                        ).map(
                          ([emoji, users]) => {
                            const count =
                              Array.isArray(
                                users
                              )
                                ? users.length
                                : 0;

                            if (!count)
                              return null;

                            return (
                              <button
                                key={emoji}
                                onClick={() =>
                                  handleReaction(
                                    message.id,
                                    emoji
                                  )
                                }
                                className="absolute -bottom-3 left-2 rounded-full border bg-white px-2 py-0.5 text-xs shadow dark:bg-gray-800"
                              >
                                {emoji} {count}
                              </button>
                            );
                          }
                        )}

                        {!deleted && (
                          <div className="absolute -top-10 right-0 hidden items-center gap-1 rounded-xl bg-white p-1 shadow-lg group-hover:flex dark:bg-gray-800">
                            <button
                              onClick={() =>
                                setReplyMessage(
                                  message
                                )
                              }
                              className="rounded-lg p-2 hover:bg-gray-100 dark:hover:bg-gray-700"
                            >
                              <Reply size={15} />
                            </button>

                            <button
                              onClick={() =>
                                setMenuMessage(
                                  menuMessage ===
                                    message.id
                                    ? null
                                    : message.id
                                )
                              }
                              className="rounded-lg p-2 hover:bg-gray-100 dark:hover:bg-gray-700"
                            >
                              <Smile size={15} />
                            </button>

                            <button
                              onClick={() =>
                                handleForward(
                                  message
                                )
                              }
                              className="rounded-lg p-2 hover:bg-gray-100 dark:hover:bg-gray-700"
                            >
                              ↗
                            </button>

                            {mine && (
                              <button
                                onClick={() =>
                                  deleteMessage(
                                    activeConversation.id,
                                    message.id
                                  )
                                }
                                className="rounded-lg p-2 text-red-500 hover:bg-gray-100 dark:hover:bg-gray-700"
                              >
                                <Trash2
                                  size={15}
                                />
                              </button>
                            )}
                          </div>
                        )}

                        {menuMessage ===
                          message.id && (
                          <div className="absolute right-0 top-8 z-10 flex gap-1 rounded-xl bg-white p-2 shadow-xl dark:bg-gray-800">
                            {EMOJIS.map(
                              emoji => (
                                <button
                                  key={emoji}
                                  onClick={() =>
                                    handleReaction(
                                      message.id,
                                      emoji
                                    )
                                  }
                                  className="rounded-lg p-1 text-lg hover:bg-gray-100 dark:hover:bg-gray-700"
                                >
                                  {emoji}
                                </button>
                              )
                            )}
                          </div>
                        )}

                        {mine &&
                          !deleted && (
                            <div className="mt-1 flex justify-end">
                              {message.readBy?.some(
                                (id: string) =>
                                  id !== user.uid
                              ) ? (
                                <CheckCheck
                                  size={15}
                                  className="text-blue-500"
                                />
                              ) : message.deliveredTo?.some(
                                  (id: string) =>
                                    id !== user.uid
                                ) ? (
                                <CheckCheck
                                  size={15}
                                  className="text-gray-400"
                                />
                              ) : (
                                <Check
                                  size={15}
                                  className="text-gray-400"
                                />
                              )}
                            </div>
                          )}
                      </div>
                    </div>
                  );
                })}
              </div>

              {replyMessage && (
                <div className="flex items-center justify-between border-t bg-blue-50 px-4 py-2 dark:bg-blue-950">
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-blue-600">
                      Replying to message
                    </p>
                    <p className="truncate text-sm">
                      {replyMessage.text}
                    </p>
                  </div>

                  <button
                    onClick={() =>
                      setReplyMessage(
                        null
                      )
                    }
                  >
                    <X size={18} />
                  </button>
                </div>
              )}

              {editingMessage && (
                <div className="flex items-center justify-between bg-yellow-50 px-4 py-2 text-sm dark:bg-yellow-950">
                  <span>
                    Editing message
                  </span>

                  <button
                    onClick={() => {
                      setEditingMessage(null);
                      setText("");
                    }}
                    className="font-bold text-red-500"
                  >
                    Cancel
                  </button>
                </div>
              )}

              {showEmoji && (
                <div className="flex gap-2 border-t p-3 dark:border-gray-800">
                  {EMOJIS.map(emoji => (
                    <button
                      key={emoji}
                      onClick={() => {
                        setText(
                          old =>
                            old + emoji
                        );
                        setShowEmoji(
                          false
                        );
                      }}
                      className="text-2xl"
                    >
                      {emoji}
                    </button>
                  ))}
                </div>
              )}

              <form
                onSubmit={handleSend}
                className="flex items-center gap-1 border-t p-3 dark:border-gray-800"
              >
                <input
                  ref={fileInputRef}
                  type="file"
                  hidden
                  accept="image/*,.pdf,.txt"
                  onChange={event => {
                    const file =
                      event.target.files?.[0];

                    if (file) {
                      handleFile(file);
                    }

                    event.target.value = "";
                  }}
                />

                <button
                  type="button"
                  onClick={() =>
                    fileInputRef.current?.click()
                  }
                  className="rounded-full p-3 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <ImageIcon size={20} />
                </button>

                <button
                  type="button"
                  onClick={() =>
                    setShowEmoji(
                      !showEmoji
                    )
                  }
                  className="rounded-full p-3 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-800"
                >
                  <Smile size={20} />
                </button>

                <input
                  value={text}
                  onChange={e =>
                    handleTyping(
                      e.target.value
                    )
                  }
                  placeholder={
                    editingMessage
                      ? "Edit message..."
                      : "Write a message..."
                  }
                  className="min-w-0 flex-1 rounded-full bg-gray-100 px-4 py-3 outline-none dark:bg-gray-800"
                />

                <button
                  type="submit"
                  disabled={
                    loading ||
                    !text.trim()
                  }
                  className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-blue-600 text-white disabled:opacity-40"
                >
                  <Send size={19} />
                </button>
              </form>
            </>
          )}
        </section>
      </div>
    </main>
  );
}

function ConversationItem({
  conversation,
  targetUid,
  active,
  onClick
}: {
  conversation: any;
  targetUid: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      className={`flex w-full items-center gap-3 border-b p-4 text-left dark:border-gray-800 ${
        active
          ? "bg-blue-50 dark:bg-blue-950"
          : "hover:bg-gray-50 dark:hover:bg-gray-800"
      }`}
    >
      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-blue-100 text-blue-600 dark:bg-blue-900">
        {conversation.type === "group" ? (
          <Users size={21} />
        ) : (
          <UserRound size={21} />
        )}
      </div>

      <div className="min-w-0 flex-1">
        <p className="truncate font-bold">
          {conversation.type === "group"
            ? conversation.name
            : targetUid ||
              "Homebook user"}
        </p>

        <p className="truncate text-sm text-gray-500">
          {conversation.lastMessage ||
            "Start a conversation"}
        </p>
      </div>

      {conversation.membership?.pinned && (
        <Pin
          size={14}
          className="text-blue-500"
        />
      )}

      {conversation.membership?.muted && (
        <VolumeX
          size={14}
          className="text-gray-400"
        />
      )}

      {conversation.membership?.unreadCount > 0 && (
        <span className="rounded-full bg-blue-600 px-2 py-1 text-xs font-bold text-white">
          {conversation.membership.unreadCount}
        </span>
      )}
    </button>
  );
}