import { useState } from "react";
import { User } from "firebase/auth";
import { createPost } from "../services/posts";
import { getUserProfile } from "../services/profile";

export default function CreatePost({
  user
}: {
  user: User;
}) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);

  async function submit() {
    if (!text.trim()) return;

    try {
      setLoading(true);

      const profile = await getUserProfile(
        user.uid
      );

      await createPost(
        user.uid,
        profile?.fullName ||
          user.displayName ||
          "Homebook User",
        profile?.username || "",
        profile?.photoURL ||
          user.photoURL ||
          null,
        text
      );

      setText("");
      window.location.reload();
    } catch (error: any) {
      alert(
        error?.message ||
        "Could not create post."
      );
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="rounded-2xl bg-white p-4 shadow-sm dark:bg-gray-900">
      <textarea
        value={text}
        onChange={e =>
          setText(e.target.value)
        }
        maxLength={5000}
        placeholder="What's on your mind?"
        className="min-h-28 w-full resize-none rounded-xl bg-gray-100 p-4 outline-none dark:bg-gray-800"
      />

      <div className="mt-3 flex items-center justify-between">
        <span className="text-xs text-gray-500">
          {text.length}/5000
        </span>

        <button
          onClick={submit}
          disabled={loading || !text.trim()}
          className="rounded-xl bg-blue-600 px-5 py-2 font-bold text-white disabled:opacity-40"
        >
          {loading ? "Posting..." : "Post"}
        </button>
      </div>
    </div>
  );
}