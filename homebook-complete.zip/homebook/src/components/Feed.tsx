import { useEffect, useState } from "react";
import { User } from "firebase/auth";
import { getPosts } from "../services/posts";
import PostCard from "./PostCard";
import { Post } from "../types/post";

export default function Feed({
  user
}: {
  user: User;
}) {
  const [posts, setPosts] =
    useState<Post[]>([]);
  const [loading, setLoading] =
    useState(true);

  useEffect(() => {
    getPosts()
      .then(items =>
        setPosts(items as Post[])
      )
      .catch(console.error)
      .finally(() =>
        setLoading(false)
      );
  }, []);

  if (loading) {
    return (
      <div className="py-10 text-center text-gray-500">
        Loading feed...
      </div>
    );
  }

  return (
    <div>
      {posts.length === 0 ? (
        <div className="mt-4 rounded-2xl bg-white p-8 text-center text-gray-500 dark:bg-gray-900">
          No posts yet.
        </div>
      ) : (
        posts.map(post => (
          <PostCard
            key={post.id}
            post={post}
            user={user}
          />
        ))
      )}
    </div>
  );
}