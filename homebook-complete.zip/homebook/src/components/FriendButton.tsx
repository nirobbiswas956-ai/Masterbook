import { useState } from "react";
import { sendFriendRequest } from "../services/social";

export default function FriendButton({
  senderId,
  receiverId
}: {
  senderId: string;
  receiverId: string;
}) {
  const [sent, setSent] =
    useState(false);

  async function send() {
    try {
      await sendFriendRequest(
        senderId,
        receiverId
      );
      setSent(true);
    } catch (error: any) {
      alert(
        error?.message ||
        "Could not send request."
      );
    }
  }

  return (
    <button
      onClick={send}
      disabled={sent}
      className="rounded-xl border border-blue-600 px-3 py-2 text-xs font-bold text-blue-600 disabled:opacity-50"
    >
      {sent
        ? "Requested"
        : "Add friend"}
    </button>
  );
}