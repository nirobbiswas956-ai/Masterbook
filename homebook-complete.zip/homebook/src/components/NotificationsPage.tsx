import { useEffect, useState } from "react";
import {
  Bell,
  CheckCheck
} from "lucide-react";
import {
  listenNotifications,
  markAllNotificationsRead,
  markNotificationRead
} from "../services/notifications";

export default function NotificationsPage({
  uid
}: {
  uid: string;
}) {
  const [notifications, setNotifications] =
    useState<any[]>([]);

  useEffect(() => {
    return listenNotifications(
      uid,
      setNotifications
    );
  }, [uid]);

  const unread =
    notifications.filter(
      item => !item.read
    ).length;

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 pb-24">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Bell
            className="text-blue-600"
            size={27}
          />
          <h1 className="text-2xl font-black">
            Notifications
          </h1>
        </div>

        {unread > 0 && (
          <button
            onClick={() =>
              markAllNotificationsRead(uid)
            }
            className="flex items-center gap-2 rounded-xl bg-blue-50 px-4 py-2 text-sm font-bold text-blue-600"
          >
            <CheckCheck size={17} />
            Mark all read
          </button>
        )}
      </div>

      <div className="mt-5 space-y-2">
        {notifications.length === 0 && (
          <div className="rounded-2xl bg-white p-8 text-center shadow-sm dark:bg-gray-900">
            <Bell
              className="mx-auto text-gray-400"
              size={40}
            />
            <p className="mt-3 text-gray-500">
              No notifications yet.
            </p>
          </div>
        )}

        {notifications.map(item => (
          <button
            key={item.id}
            onClick={() =>
              markNotificationRead(
                item.id
              )
            }
            className={`w-full rounded-2xl p-4 text-left ${
              item.read
                ? "bg-white dark:bg-gray-900"
                : "bg-blue-50 dark:bg-blue-950"
            }`}
          >
            <div className="flex gap-3">
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-full bg-blue-100 text-blue-600">
                <Bell size={20} />
              </div>

              <div>
                <p className="font-semibold">
                  {item.text}
                </p>

                {!item.read && (
                  <p className="mt-1 text-xs font-bold text-blue-600">
                    New
                  </p>
                )}
              </div>
            </div>
          </button>
        ))}
      </div>
    </main>
  );
}