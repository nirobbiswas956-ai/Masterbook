import { useState } from "react";
import { Search } from "lucide-react";
import { searchUsers } from "../services/social";
import FollowButton from "./FollowButton";
import FriendButton from "./FriendButton";

export default function UserSearch({
  myUid
}: {
  myUid: string;
}) {
  const [text, setText] = useState("");
  const [results, setResults] = useState<any[]>([]);

  async function search(value: string) {
    setText(value);

    if (!value.trim()) {
      setResults([]);
      return;
    }

    try {
      setResults(
        (await searchUsers(value)).filter(
          item => item.id !== myUid
        )
      );
    } catch (error) {
      console.error(error);
    }
  }

  return (
    <main className="mx-auto max-w-3xl px-4 py-6 pb-24">
      <h1 className="text-2xl font-black">
        Search
      </h1>

      <div className="relative mt-4">
        <Search
          className="absolute left-3 top-3.5 text-gray-400"
          size={19}
        />

        <input
          value={text}
          onChange={e =>
            search(e.target.value)
          }
          placeholder="Search username..."
          className="w-full rounded-xl bg-white py-3 pl-10 pr-4 shadow-sm outline-none dark:bg-gray-900"
        />
      </div>

      <div className="mt-4 space-y-2">
        {results.map(user => (
          <div
            key={user.id}
            className="flex items-center gap-3 rounded-2xl bg-white p-4 shadow-sm dark:bg-gray-900"
          >
            {user.photoURL ? (
              <img
                src={user.photoURL}
                alt=""
                className="h-12 w-12 rounded-full object-cover"
              />
            ) : (
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-blue-100 font-bold text-blue-600">
                {user.fullName?.charAt(0)}
              </div>
            )}

            <div className="min-w-0 flex-1">
              <p className="font-bold">
                {user.fullName}
              </p>
              <p className="text-sm text-gray-500">
                @{user.username}
              </p>
            </div>

            <div className="flex gap-2">
              <FollowButton
                myUid={myUid}
                targetUid={user.id}
              />
              <FriendButton
                senderId={myUid}
                receiverId={user.id}
              />
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}