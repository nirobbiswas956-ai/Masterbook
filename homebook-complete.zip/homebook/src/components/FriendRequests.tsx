import { useEffect, useState } from "react";
import {
  collection,
  onSnapshot,
  query,
  where
} from "firebase/firestore";
import { db } from "../lib/firebase";
import {
  acceptFriendRequest,
  rejectFriendRequest
} from "../services/social";

export default function FriendRequests({
  uid
}: {
  uid: string;
}) {
  const [requests, setRequests] =
    useState<any[]>([]);

  useEffect(() => {
    const q = query(
      collection(
        db,
        "friendRequests"
      ),
      where(
        "receiverId",
        "==",
        uid
      ),
      where(
        "status",
        "==",
        "pending"
      )
    );

    return onSnapshot(q, snapshot => {
      setRequests(
        snapshot.docs.map(item => ({
          id: item.id,
          ...item.data()
        }))
      );
    });
  }, [uid]);

  return (
    <div className="space-y-3">
      {requests.map(request => (
        <div
          key={request.id}
          className="rounded-2xl bg-white p-4 shadow-sm dark:bg-gray-900"
        >
          <p className="font-bold">
            Someone sent you a friend request.
          </p>

          <div className="mt-3 flex gap-2">
            <button
              onClick={() =>
                acceptFriendRequest(
                  request.id,
                  request.senderId,
                  request.receiverId
                )
              }
              className="rounded-xl bg-blue-600 px-4 py-2 text-sm font-bold text-white"
            >
              Accept
            </button>

            <button
              onClick={() =>
                rejectFriendRequest(
                  request.id
                )
              }
              className="rounded-xl bg-gray-100 px-4 py-2 text-sm font-bold dark:bg-gray-800"
            >
              Reject
            </button>
          </div>
        </div>
      ))}
    </div>
  );
}