import { useState } from "react";
import { User } from "firebase/auth";
import {
  MessageCircle,
  Share2,
  ThumbsUp,
  Trash2
} from "lucide-react";
import { Post } from "../types/post";
import {
  addComment,
  deletePost,
  likePost,
  sharePost
} from "../services/posts";
import { createNotification } from "../services/notifications";

export default function PostCard({
  post,
  user
}: {
  post: Post;
  user: User;
}) {
  const [comment, setComment] =
    useState("");

  async function like() {
    try {
      await likePost(
        post.id,
        user.uid
      );

      if (post.authorId !== user.uid) {
        await createNotification(
          post.authorId,
          user.uid,
          "like",
          `${user.displayName || "Someone"} liked your post.`,
          post.id
        );
      }

      window.location.reload();
    } catch (error: any) {
      alert(error?.message || "Like failed.");
    }
  }

  async function commentPost() {
    if (!comment.trim()) return;

    try {
      await addComment(
        post.id,
        user.uid,
        user.displayName ||
          "Homebook User",
        comment
      );

      if (post.authorId !== user.uid) {
        await createNotification(
          post.authorId,
          user.uid,
          "comment",
          `${user.displayName || "Someone"} commented on your post.`,
          post.id
        );
      }

      setComment("");
      window.location.reload();
    } catch (error: any) {
      alert(
        error?.message ||
        "Comment failed."
      );
    }
  }

  async function share() {
    try {
      await sharePost(
        post.id,
        user.uid
      );

      await navigator.clipboard.writeText(
        `${window.location.origin}/post/${post.id}`
      );

      alert("Post link copied.");
      window.location.reload();
    } catch (error: any) {
      alert(
        error?.message ||
        "Share failed."
      );
    }
  }

  async function remove() {
    if (!window.confirm("Delete this post?")) {
      return;
    }

    await deletePost(post.id);
    window.location.reload();
  }

  return (
    <article className="mt-4 rounded-2xl bg-white p-4 shadow-sm dark:bg-gray-900">
      <div className="flex items-center gap-3">
        {post.authorPhotoURL ? (
          <img
            src={post.authorPhotoURL}
            alt=""
            className="h-11 w-11 rounded-full object-cover"
          />
        ) : (
          <div className="flex h-11 w-11 items-center justify-center rounded-full bg-blue-100 font-bold text-blue-600">
            {post.authorName?.charAt(0)}
          </div>
        )}

        <div className="min-w-0 flex-1">
          <p className="font-bold">
            {post.authorName}
          </p>
          <p className="text-xs text-gray-500">
            @{post.authorUsername}
          </p>
        </div>

        {post.authorId === user.uid && (
          <button
            onClick={remove}
            className="rounded-lg p-2 text-red-500 hover:bg-red-50"
          >
            <Trash2 size={18} />
          </button>
        )}
      </div>

      <p className="mt-4 whitespace-pre-wrap break-words">
        {post.text}
      </p>

      <div className="mt-4 flex justify-between border-y py-2 text-sm text-gray-500">
        <span>{post.likeCount} Likes</span>
        <span>{post.commentCount} Comments</span>
        <span>{post.shareCount} Shares</span>
      </div>

      <div className="grid grid-cols-3 gap-1 py-2">
        <button
          onClick={like}
          className="flex items-center justify-center gap-2 rounded-xl py-2 hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <ThumbsUp size={18} />
          Like
        </button>

        <button
          onClick={() =>
            document
              .getElementById(
                `comment-${post.id}`
              )
              ?.focus()
          }
          className="flex items-center justify-center gap-2 rounded-xl py-2 hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <MessageCircle size={18} />
          Comment
        </button>

        <button
          onClick={share}
          className="flex items-center justify-center gap-2 rounded-xl py-2 hover:bg-gray-100 dark:hover:bg-gray-800"
        >
          <Share2 size={18} />
          Share
        </button>
      </div>

      <div className="flex gap-2">
        <input
          id={`comment-${post.id}`}
          value={comment}
          onChange={e =>
            setComment(e.target.value)
          }
          placeholder="Write a comment..."
          className="flex-1 rounded-xl bg-gray-100 px-4 py-2 outline-none dark:bg-gray-800"
        />

        <button
          onClick={commentPost}
          className="rounded-xl bg-blue-600 px-4 font-bold text-white"
        >
          Send
        </button>
      </div>
    </article>
  );
}