export type UserProfile = {
  uid: string;
  fullName: string;
  username: string;
  email: string;
  photoURL: string | null;
  coverURL?: string | null;
  bio: string;
  createdAt: unknown;
  updatedAt: unknown;
};