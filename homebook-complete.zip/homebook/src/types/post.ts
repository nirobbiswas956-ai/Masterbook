export type Post = {
  id: string;
  authorId: string;
  authorName: string;
  authorUsername: string;
  authorPhotoURL: string | null;
  text: string;
  likeCount: number;
  commentCount: number;
  shareCount: number;
  createdAt: any;
};