import {
  batch,
  doc,
  getDoc,
  getDocs,
  collection,
  limit,
  query,
  serverTimestamp,
  setDoc,
  deleteDoc,
  where,
  orderBy
} from "firebase/firestore";
import { db } from "../lib/firebase";
import { createNotification } from "./notifications";

export async function followUser(
  myUid: string,
  targetUid: string
) {
  if (myUid === targetUid) return;

  await setDoc(
    doc(db, "follows", `${myUid}_${targetUid}`),
    {
      followerId: myUid,
      followingId: targetUid,
      createdAt: serverTimestamp()
    }
  );

  await createNotification(
    targetUid,
    myUid,
    "follow",
    "You have a new follower.",
    myUid
  );
}

export async function unfollowUser(
  myUid: string,
  targetUid: string
) {
  await deleteDoc(
    doc(db, "follows", `${myUid}_${targetUid}`)
  );
}

export async function isFollowing(
  myUid: string,
  targetUid: string
) {
  const snapshot = await getDoc(
    doc(db, "follows", `${myUid}_${targetUid}`)
  );
  return snapshot.exists();
}

export async function sendFriendRequest(
  senderId: string,
  receiverId: string
) {
  if (senderId === receiverId) {
    throw new Error("You cannot send a request to yourself.");
  }

  const requestId = `${senderId}_${receiverId}`;

  await setDoc(
    doc(db, "friendRequests", requestId),
    {
      senderId,
      receiverId,
      status: "pending",
      createdAt: serverTimestamp(),
      updatedAt: serverTimestamp()
    }
  );

  await createNotification(
    receiverId,
    senderId,
    "friend_request",
    "You received a new friend request.",
    requestId
  );

  return requestId;
}

export async function cancelFriendRequest(
  senderId: string,
  receiverId: string
) {
  await deleteDoc(
    doc(
      db,
      "friendRequests",
      `${senderId}_${receiverId}`
    )
  );
}

export async function acceptFriendRequest(
  requestId: string,
  senderId: string,
  receiverId: string
) {
  const userA =
    senderId < receiverId ? senderId : receiverId;
  const userB =
    senderId < receiverId ? receiverId : senderId;

  const b = batch();

  b.set(
    doc(db, "friendships", `${userA}_${userB}`),
    {
      userA,
      userB,
      createdAt: serverTimestamp()
    }
  );

  b.update(
    doc(db, "friendRequests", requestId),
    {
      status: "accepted",
      updatedAt: serverTimestamp()
    }
  );

  await b.commit();

  await createNotification(
    senderId,
    receiverId,
    "friend_accepted",
    "Your friend request was accepted.",
    requestId
  );
}

export async function rejectFriendRequest(
  requestId: string
) {
  await deleteDoc(
    doc(db, "friendRequests", requestId)
  );
}

export async function areFriends(
  uidA: string,
  uidB: string
) {
  const a = uidA < uidB ? uidA : uidB;
  const b = uidA < uidB ? uidB : uidA;

  const snapshot = await getDoc(
    doc(db, "friendships", `${a}_${b}`)
  );

  return snapshot.exists();
}

export async function blockUser(
  myUid: string,
  targetUid: string
) {
  await setDoc(
    doc(db, "blocks", `${myUid}_${targetUid}`),
    {
      blockerId: myUid,
      blockedId: targetUid,
      createdAt: serverTimestamp()
    }
  );

  await deleteDoc(
    doc(db, "follows", `${myUid}_${targetUid}`)
  );
}

export async function unblockUser(
  myUid: string,
  targetUid: string
) {
  await deleteDoc(
    doc(db, "blocks", `${myUid}_${targetUid}`)
  );
}

export async function isBlocked(
  myUid: string,
  targetUid: string
) {
  const snapshot = await getDoc(
    doc(db, "blocks", `${myUid}_${targetUid}`)
  );
  return snapshot.exists();
}

export async function muteUser(
  myUid: string,
  targetUid: string
) {
  await setDoc(
    doc(db, "mutes", `${myUid}_${targetUid}`),
    {
      muterId: myUid,
      mutedId: targetUid,
      createdAt: serverTimestamp()
    }
  );
}

export async function unmuteUser(
  myUid: string,
  targetUid: string
) {
  await deleteDoc(
    doc(db, "mutes", `${myUid}_${targetUid}`)
  );
}

export async function searchUsers(
  searchText: string
) {
  const value = searchText.trim().toLowerCase();

  if (!value) return [];

  const q = query(
    collection(db, "users"),
    orderBy("username"),
    where("username", ">=", value),
    where("username", "<=", value + "\uf8ff"),
    limit(20)
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(item => ({
    id: item.id,
    ...item.data()
  }));
}