import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDocs,
  increment,
  limit,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where
} from "firebase/firestore";
import { db } from "../lib/firebase";

export async function createPost(
  authorId: string,
  authorName: string,
  authorUsername: string,
  authorPhotoURL: string | null,
  text: string
) {
  const cleanText = text.trim();

  if (!cleanText) throw new Error("Post cannot be empty.");
  if (cleanText.length > 5000) {
    throw new Error("Post cannot exceed 5000 characters.");
  }

  return addDoc(collection(db, "posts"), {
    authorId,
    authorName,
    authorUsername,
    authorPhotoURL,
    text: cleanText,
    likeCount: 0,
    commentCount: 0,
    shareCount: 0,
    createdAt: serverTimestamp()
  });
}

export async function getPosts() {
  const q = query(
    collection(db, "posts"),
    orderBy("createdAt", "desc"),
    limit(20)
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(item => ({
    id: item.id,
    ...item.data()
  }));
}

export async function deletePost(postId: string) {
  await deleteDoc(doc(db, "posts", postId));
}

export async function likePost(postId: string, uid: string) {
  const existingQuery = query(
    collection(db, "reactions"),
    where("uid", "==", uid),
    where("postId", "==", postId),
    limit(1)
  );

  const existing = await getDocs(existingQuery);

  if (!existing.empty) {
    await deleteDoc(existing.docs[0].ref);
    await updateDoc(doc(db, "posts", postId), {
      likeCount: increment(-1)
    });
    return false;
  }

  await addDoc(collection(db, "reactions"), {
    uid,
    postId,
    type: "like",
    createdAt: serverTimestamp()
  });

  await updateDoc(doc(db, "posts", postId), {
    likeCount: increment(1)
  });

  return true;
}

export async function addComment(
  postId: string,
  uid: string,
  authorName: string,
  text: string
) {
  const cleanText = text.trim();

  if (!cleanText) throw new Error("Comment cannot be empty.");
  if (cleanText.length > 2000) {
    throw new Error("Comment is too long.");
  }

  await addDoc(
    collection(db, "posts", postId, "comments"),
    {
      uid,
      authorName,
      text: cleanText,
      createdAt: serverTimestamp()
    }
  );

  await updateDoc(doc(db, "posts", postId), {
    commentCount: increment(1)
  });
}

export async function sharePost(
  postId: string,
  uid: string
) {
  await addDoc(collection(db, "shares"), {
    postId,
    uid,
    createdAt: serverTimestamp()
  });

  await updateDoc(doc(db, "posts", postId), {
    shareCount: increment(1)
  });
}