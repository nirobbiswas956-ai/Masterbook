import {
  getDownloadURL,
  ref,
  uploadBytes
} from "firebase/storage";
import { storage } from "../lib/firebase";

const MAX_IMAGE_SIZE = 5 * 1024 * 1024;

const allowedProfileTypes = [
  "image/jpeg",
  "image/png",
  "image/webp"
];

export async function uploadProfileImage(
  uid: string,
  file: File,
  type: "avatar" | "cover"
) {
  if (!allowedProfileTypes.includes(file.type)) {
    throw new Error("Only JPG, PNG or WebP images are allowed.");
  }

  if (file.size > MAX_IMAGE_SIZE) {
    throw new Error("Image must be smaller than 5 MB.");
  }

  const extension = file.name.split(".").pop() || "jpg";

  const filePath =
    type === "avatar"
      ? `users/${uid}/profile/avatar.${extension}`
      : `users/${uid}/profile/cover.${extension}`;

  const storageRef = ref(storage, filePath);

  await uploadBytes(storageRef, file, {
    contentType: file.type
  });

  return await getDownloadURL(storageRef);
}

export async function uploadMessageFile(
  uid: string,
  conversationId: string,
  file: File
) {
  const allowedTypes = [
    "image/jpeg",
    "image/png",
    "image/webp",
    "image/gif",
    "application/pdf",
    "text/plain"
  ];

  const MAX_FILE_SIZE = 10 * 1024 * 1024;

  if (!allowedTypes.includes(file.type)) {
    throw new Error("This file type is not supported.");
  }

  if (file.size > MAX_FILE_SIZE) {
    throw new Error("File must be smaller than 10 MB.");
  }

  const extension = file.name.split(".").pop() || "bin";

  const filePath =
    `messages/${conversationId}/${uid}/${Date.now()}.${extension}`;

  const storageRef = ref(storage, filePath);

  await uploadBytes(storageRef, file, {
    contentType: file.type
  });

  return await getDownloadURL(storageRef);
}