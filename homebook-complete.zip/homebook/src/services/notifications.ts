import {
  addDoc,
  collection,
  doc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  updateDoc,
  where,
  writeBatch
} from "firebase/firestore";

import { db } from "../lib/firebase";

export type NotificationType =
  | "friend_request"
  | "friend_accepted"
  | "follow"
  | "like"
  | "comment"
  | "share"
  | "message";

export async function createNotification(
  receiverId: string,
  senderId: string,
  type: NotificationType,
  text: string,
  targetId?: string
) {
  if (receiverId === senderId) return;

  await addDoc(
    collection(db, "notifications"),
    {
      receiverId,
      senderId,
      type,
      text,
      targetId: targetId || null,
      read: false,
      createdAt: serverTimestamp()
    }
  );
}

export function listenNotifications(
  uid: string,
  callback: (items: any[]) => void
) {
  const q = query(
    collection(db, "notifications"),
    where("receiverId", "==", uid),
    orderBy("createdAt", "desc"),
    limit(50)
  );

  return onSnapshot(
    q,
    snapshot => {
      callback(
        snapshot.docs.map(item => ({
          id: item.id,
          ...item.data()
        }))
      );
    },
    error => {
      console.error(error);
      callback([]);
    }
  );
}

export async function markNotificationRead(
  notificationId: string
) {
  await updateDoc(
    doc(db, "notifications", notificationId),
    { read: true }
  );
}

export async function markAllNotificationsRead(
  uid: string
) {
  const q = query(
    collection(db, "notifications"),
    where("receiverId", "==", uid),
    where("read", "==", false),
    limit(100)
  );

  const snapshot = await getDocs(q);
  const b = writeBatch(db);

  snapshot.docs.forEach(item => {
    b.update(item.ref, { read: true });
  });

  await b.commit();
}