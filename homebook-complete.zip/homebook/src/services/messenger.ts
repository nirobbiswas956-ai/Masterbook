import {
  addDoc,
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  limit,
  onSnapshot,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  updateDoc,
  where
} from "firebase/firestore";

import { db } from "../lib/firebase";

function makeConversationId(uidA: string, uidB: string) {
  return uidA < uidB
    ? `${uidA}_${uidB}`
    : `${uidB}_${uidA}`;
}

export async function getUserInfo(uid: string) {
  const snapshot = await getDoc(doc(db, "users", uid));
  if (!snapshot.exists()) return null;

  return {
    id: snapshot.id,
    ...snapshot.data()
  };
}

export async function searchMessengerUsers(searchText: string) {
  const value = searchText.trim().toLowerCase();
  if (!value) return [];

  const q = query(
    collection(db, "users"),
    orderBy("username"),
    where("username", ">=", value),
    where("username", "<=", value + "\uf8ff"),
    limit(15)
  );

  const snapshot = await getDocs(q);

  return snapshot.docs.map(item => ({
    id: item.id,
    ...item.data()
  }));
}

export async function createDirectConversation(
  myUid: string,
  otherUid: string
) {
  if (myUid === otherUid) {
    throw new Error("You cannot message yourself.");
  }

  const conversationId =
    makeConversationId(myUid, otherUid);

  await setDoc(
    doc(db, "conversations", conversationId),
    {
      type: "direct",
      createdBy: myUid,
      memberIds: [myUid, otherUid],
      updatedAt: serverTimestamp(),
      archivedBy: [],
      mutedBy: [],
      pinnedBy: []
    },
    { merge: true }
  );

  for (const uid of [myUid, otherUid]) {
    await setDoc(
      doc(
        db,
        "conversationMembers",
        `${conversationId}_${uid}`
      ),
      {
        conversationId,
        userId: uid,
        joinedAt: serverTimestamp(),
        unreadCount: 0,
        muted: false,
        archived: false,
        pinned: false
      },
      { merge: true }
    );
  }

  return conversationId;
}

export async function createGroupConversation(
  creatorUid: string,
  memberIds: string[],
  groupName: string
) {
  const cleanName = groupName.trim();

  if (!cleanName) {
    throw new Error("Group name is required.");
  }

  const members = Array.from(
    new Set([creatorUid, ...memberIds])
  );

  if (members.length < 3) {
    throw new Error("A group needs at least 3 members.");
  }

  const conversationRef = await addDoc(
    collection(db, "conversations"),
    {
      type: "group",
      name: cleanName,
      createdBy: creatorUid,
      memberIds: members,
      admins: [creatorUid],
      updatedAt: serverTimestamp(),
      archivedBy: [],
      mutedBy: [],
      pinnedBy: []
    }
  );

  for (const uid of members) {
    await setDoc(
      doc(
        db,
        "conversationMembers",
        `${conversationRef.id}_${uid}`
      ),
      {
        conversationId: conversationRef.id,
        userId: uid,
        joinedAt: serverTimestamp(),
        unreadCount: 0,
        muted: false,
        archived: false,
        pinned: false
      }
    );
  }

  return conversationRef.id;
}

export async function getConversation(
  conversationId: string
) {
  const snapshot = await getDoc(
    doc(db, "conversations", conversationId)
  );

  if (!snapshot.exists()) return null;

  return {
    id: snapshot.id,
    ...snapshot.data()
  };
}

export function listenMyConversations(
  uid: string,
  callback: (items: any[]) => void
) {
  const q = query(
    collection(db, "conversationMembers"),
    where("userId", "==", uid),
    orderBy("joinedAt", "desc"),
    limit(100)
  );

  return onSnapshot(
    q,
    async snapshot => {
      const result: any[] = [];

      for (const member of snapshot.docs) {
        const data = member.data();

        const conversation =
          await getConversation(data.conversationId);

        if (conversation) {
          result.push({
            ...conversation,
            membership: data
          });
        }
      }

      result.sort((a, b) => {
        const aTime =
          a.updatedAt?.toMillis?.() || 0;
        const bTime =
          b.updatedAt?.toMillis?.() || 0;

        return bTime - aTime;
      });

      callback(result);
    },
    error => {
      console.error(error);
      callback([]);
    }
  );
}

export async function sendMessage(
  conversationId: string,
  senderId: string,
  text: string,
  type:
    | "text"
    | "image"
    | "file"
    | "reply"
    | "forward" = "text",
  fileURL: string | null = null,
  fileName: string | null = null,
  replyTo: any = null,
  forwardedFrom: any = null
) {
  const cleanText = text.trim();

  if (type === "text" && !cleanText) {
    throw new Error("Message cannot be empty.");
  }

  const messageRef = await addDoc(
    collection(
      db,
      "conversations",
      conversationId,
      "messages"
    ),
    {
      conversationId,
      senderId,
      text: cleanText,
      type,
      fileURL,
      fileName,
      replyTo,
      forwardedFrom,
      createdAt: serverTimestamp(),
      editedAt: null,
      deliveredTo: [],
      readBy: [],
      reactions: {}
    }
  );

  await updateDoc(
    doc(db, "conversations", conversationId),
    {
      updatedAt: serverTimestamp(),
      lastMessage:
        cleanText ||
        (type === "image"
          ? "📷 Image"
          : type === "file"
            ? "📎 File"
            : "Message"),
      lastMessageSenderId: senderId
    }
  );

  return messageRef.id;
}

export function listenMessages(
  conversationId: string,
  callback: (items: any[]) => void
) {
  const q = query(
    collection(
      db,
      "conversations",
      conversationId,
      "messages"
    ),
    orderBy("createdAt", "asc"),
    limit(300)
  );

  return onSnapshot(q, snapshot => {
    callback(
      snapshot.docs.map(item => ({
        id: item.id,
        ...item.data()
      }))
    );
  });
}

export async function editMessage(
  conversationId: string,
  messageId: string,
  text: string
) {
  const cleanText = text.trim();

  if (!cleanText) {
    throw new Error("Message cannot be empty.");
  }

  await updateDoc(
    doc(
      db,
      "conversations",
      conversationId,
      "messages",
      messageId
    ),
    {
      text: cleanText,
      editedAt: serverTimestamp()
    }
  );
}

export async function deleteMessage(
  conversationId: string,
  messageId: string
) {
  await updateDoc(
    doc(
      db,
      "conversations",
      conversationId,
      "messages",
      messageId
    ),
    {
      text: "This message was deleted.",
      type: "deleted",
      editedAt: serverTimestamp()
    }
  );
}

export async function reactToMessage(
  conversationId: string,
  messageId: string,
  uid: string,
  emoji: string
) {
  const messageRef = doc(
    db,
    "conversations",
    conversationId,
    "messages",
    messageId
  );

  const snapshot = await getDoc(messageRef);
  if (!snapshot.exists()) return;

  const data = snapshot.data();
  const reactions = data.reactions || {};
  const users = Array.isArray(reactions[emoji])
    ? reactions[emoji]
    : [];

  if (users.includes(uid)) {
    reactions[emoji] =
      users.filter((id: string) => id !== uid);
  } else {
    reactions[emoji] = [...users, uid];
  }

  await updateDoc(messageRef, { reactions });
}

export async function pinMessage(
  conversationId: string,
  messageId: string
) {
  await setDoc(
    doc(
      db,
      "conversations",
      conversationId,
      "pinnedMessages",
      messageId
    ),
    {
      messageId,
      pinnedAt: serverTimestamp()
    }
  );
}

export async function unpinMessage(
  conversationId: string,
  messageId: string
) {
  await deleteDoc(
    doc(
      db,
      "conversations",
      conversationId,
      "pinnedMessages",
      messageId
    )
  );
}

export async function toggleMuteConversation(
  conversationId: string,
  uid: string,
  muted: boolean
) {
  await updateDoc(
    doc(
      db,
      "conversationMembers",
      `${conversationId}_${uid}`
    ),
    { muted }
  );
}

export async function toggleArchiveConversation(
  conversationId: string,
  uid: string,
  archived: boolean
) {
  await updateDoc(
    doc(
      db,
      "conversationMembers",
      `${conversationId}_${uid}`
    ),
    { archived }
  );
}

export async function togglePinConversation(
  conversationId: string,
  uid: string,
  pinned: boolean
) {
  await updateDoc(
    doc(
      db,
      "conversationMembers",
      `${conversationId}_${uid}`
    ),
    { pinned }
  );
}

export async function markMessageDelivered(
  conversationId: string,
  messageId: string,
  uid: string
) {
  const messageRef = doc(
    db,
    "conversations",
    conversationId,
    "messages",
    messageId
  );

  const snapshot = await getDoc(messageRef);
  if (!snapshot.exists()) return;

  const data = snapshot.data();
  const deliveredTo =
    Array.isArray(data.deliveredTo)
      ? data.deliveredTo
      : [];

  if (!deliveredTo.includes(uid)) {
    await updateDoc(messageRef, {
      deliveredTo: [...deliveredTo, uid]
    });
  }
}

export async function markMessageRead(
  conversationId: string,
  messageId: string,
  uid: string
) {
  const messageRef = doc(
    db,
    "conversations",
    conversationId,
    "messages",
    messageId
  );

  const snapshot = await getDoc(messageRef);
  if (!snapshot.exists()) return;

  const data = snapshot.data();
  const readBy =
    Array.isArray(data.readBy)
      ? data.readBy
      : [];

  if (!readBy.includes(uid)) {
    await updateDoc(messageRef, {
      readBy: [...readBy, uid]
    });
  }
}

export async function updatePresence(
  uid: string,
  online: boolean
) {
  await setDoc(
    doc(db, "presence", uid),
    {
      uid,
      online,
      lastActive: serverTimestamp()
    },
    { merge: true }
  );
}

export function listenPresence(
  uid: string,
  callback: (data: any) => void
) {
  return onSnapshot(
    doc(db, "presence", uid),
    snapshot => {
      callback(
        snapshot.exists()
          ? snapshot.data()
          : { online: false }
      );
    }
  );
}

export async function setTyping(
  conversationId: string,
  uid: string,
  typing: boolean
) {
  await setDoc(
    doc(
      db,
      "typing",
      `${conversationId}_${uid}`
    ),
    {
      conversationId,
      uid,
      typing,
      updatedAt: serverTimestamp()
    },
    { merge: true }
  );
}

export function listenTyping(
  conversationId: string,
  otherUid: string,
  callback: (typing: boolean) => void
) {
  return onSnapshot(
    doc(
      db,
      "typing",
      `${conversationId}_${otherUid}`
    ),
    snapshot => {
      callback(
        snapshot.exists() &&
        snapshot.data().typing === true
      );
    }
  );
}

export async function clearUnread(
  conversationId: string,
  uid: string
) {
  await updateDoc(
    doc(
      db,
      "conversationMembers",
      `${conversationId}_${uid}`
    ),
    { unreadCount: 0 }
  );
}