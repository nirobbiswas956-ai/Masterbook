import {
  doc,
  getDoc,
  serverTimestamp,
  updateDoc
} from "firebase/firestore";
import { updateProfile } from "firebase/auth";
import { db, auth } from "../lib/firebase";

export async function getUserProfile(uid: string) {
  const snapshot = await getDoc(doc(db, "users", uid));

  if (!snapshot.exists()) return null;

  return {
    id: snapshot.id,
    ...snapshot.data()
  };
}

export async function updateUserProfile(
  uid: string,
  data: {
    fullName?: string;
    username?: string;
    bio?: string;
    photoURL?: string | null;
    coverURL?: string | null;
  }
) {
  await updateDoc(doc(db, "users", uid), {
    ...data,
    updatedAt: serverTimestamp()
  });

  if (data.fullName !== undefined && auth.currentUser) {
    await updateProfile(auth.currentUser, {
      displayName: data.fullName
    });
  }
}

export async function updateUserBio(uid: string, bio: string) {
  await updateUserProfile(uid, { bio });
}