import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile
} from "firebase/auth";
import {
  doc,
  serverTimestamp,
  setDoc
} from "firebase/firestore";
import { auth, db } from "../lib/firebase";

export async function registerUser(
  fullName: string,
  username: string,
  email: string,
  password: string
) {
  const usernameClean = username
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9_]/g, "");

  if (!fullName.trim()) {
    throw new Error("Full name is required.");
  }

  if (!usernameClean) {
    throw new Error("Username is required.");
  }

  if (password.length < 8) {
    throw new Error("Password must contain at least 8 characters.");
  }

  const credential = await createUserWithEmailAndPassword(
    auth,
    email.trim(),
    password
  );

  const user = credential.user;

  await updateProfile(user, {
    displayName: fullName.trim()
  });

  await setDoc(doc(db, "users", user.uid), {
    uid: user.uid,
    fullName: fullName.trim(),
    username: usernameClean,
    email: user.email ?? "",
    photoURL: null,
    coverURL: null,
    bio: "",
    createdAt: serverTimestamp(),
    updatedAt: serverTimestamp()
  });

  return user;
}

export async function loginUser(email: string, password: string) {
  const credential = await signInWithEmailAndPassword(
    auth,
    email.trim(),
    password
  );
  return credential.user;
}

export async function logoutUser() {
  await signOut(auth);
}