import {
  useEffect,
  useState
} from "react";

import {
  Bell,
  Home,
  LogOut,
  Menu,
  MessageCircle,
  Moon,
  Search,
  Sun,
  UserRound,
  Users
} from "lucide-react";

import { User } from "firebase/auth";

import { useAuth } from "./hooks/useAuth";
import AuthScreen from "./components/AuthScreen";
import CreatePost from "./components/CreatePost";
import Feed from "./components/Feed";
import ProfilePage from "./components/ProfilePage";
import UserSearch from "./components/UserSearch";
import MessengerPage from "./components/MessengerPage";
import NotificationsPage from "./components/NotificationsPage";
import { logoutUser } from "./services/auth";

type Screen =
  | "home"
  | "search"
  | "messenger"
  | "notifications"
  | "profile"
  | "menu";

export default function App() {
  const {
    user,
    loading,
    isLoggedIn
  } = useAuth();

  const [screen, setScreen] =
    useState<Screen>("home");

  const [dark, setDark] =
    useState(false);

  useEffect(() => {
    const saved =
      localStorage.getItem(
        "homebook-dark"
      ) === "true";

    setDark(saved);

    document.documentElement.classList.toggle(
      "dark",
      saved
    );
  }, []);

  function toggleDark() {
    const next = !dark;

    setDark(next);

    localStorage.setItem(
      "homebook-dark",
      String(next)
    );

    document.documentElement.classList.toggle(
      "dark",
      next
    );
  }

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-[#f0f2f5]">
        <div className="text-center">
          <img
            src="/logo.svg"
            alt="Homebook"
            className="mx-auto h-20 w-20"
          />
          <p className="mt-4 font-bold text-blue-600">
            Loading Homebook...
          </p>
        </div>
      </div>
    );
  }

  if (!isLoggedIn || !user) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-[#f0f2f5] dark:bg-gray-950 dark:text-white">

      <Header
        user={user}
        screen={screen}
        setScreen={setScreen}
        dark={dark}
        toggleDark={toggleDark}
      />

      {screen === "home" && (
        <HomePage user={user} />
      )}

      {screen === "search" && (
        <UserSearch myUid={user.uid} />
      )}

      {screen === "messenger" && (
        <MessengerPage user={user} />
      )}

      {screen === "notifications" && (
        <NotificationsPage uid={user.uid} />
      )}

      {screen === "profile" && (
        <ProfilePage user={user} />
      )}

      {screen === "menu" && (
        <MenuPage
          user={user}
          dark={dark}
          toggleDark={toggleDark}
        />
      )}

      <BottomNav
        screen={screen}
        setScreen={setScreen}
      />
    </div>
  );
}

function Header({
  user,
  screen,
  setScreen,
  dark,
  toggleDark
}: {
  user: User;
  screen: Screen;
  setScreen: (screen: Screen) => void;
  dark: boolean;
  toggleDark: () => void;
}) {
  return (
    <header className="sticky top-0 z-30 border-b bg-white/95 backdrop-blur dark:border-gray-800 dark:bg-gray-900/95">
      <div className="mx-auto flex max-w-6xl items-center gap-3 px-4 py-3">

        <button
          onClick={() =>
            setScreen("home")
          }
          className="flex items-center gap-2"
        >
          <img
            src="/logo.svg"
            alt="Homebook"
            className="h-9 w-9"
          />

          <span className="hidden text-xl font-black text-blue-600 sm:block">
            Homebook
          </span>
        </button>

        <button
          onClick={() =>
            setScreen("search")
          }
          className="ml-auto rounded-full bg-gray-100 p-2.5 dark:bg-gray-800"
        >
          <Search size={20} />
        </button>

        <button
          onClick={() =>
            setScreen("messenger")
          }
          className="rounded-full bg-gray-100 p-2.5 dark:bg-gray-800"
        >
          <MessageCircle size={20} />
        </button>

        <button
          onClick={() =>
            setScreen("notifications")
          }
          className="rounded-full bg-gray-100 p-2.5 dark:bg-gray-800"
        >
          <Bell size={20} />
        </button>

        <button
          onClick={toggleDark}
          className="hidden rounded-full bg-gray-100 p-2.5 dark:bg-gray-800 sm:block"
        >
          {dark ? (
            <Sun size={20} />
          ) : (
            <Moon size={20} />
          )}
        </button>

        <button
          onClick={() =>
            setScreen("profile")
          }
          className="rounded-full bg-blue-100 p-2.5 text-blue-600 dark:bg-blue-950"
        >
          <UserRound size={20} />
        </button>

      </div>
    </header>
  );
}

function BottomNav({
  screen,
  setScreen
}: {
  screen: Screen;
  setScreen: (screen: Screen) => void;
}) {
  const items: {
    screen: Screen;
    label: string;
    icon: any;
  }[] = [
    {
      screen: "home",
      label: "Home",
      icon: Home
    },
    {
      screen: "search",
      label: "Search",
      icon: Search
    },
    {
      screen: "messenger",
      label: "Chat",
      icon: MessageCircle
    },
    {
      screen: "notifications",
      label: "Alerts",
      icon: Bell
    },
    {
      screen: "profile",
      label: "Profile",
      icon: UserRound
    }
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 border-t bg-white/95 backdrop-blur dark:border-gray-800 dark:bg-gray-900/95 sm:hidden">
      <div className="grid grid-cols-5">
        {items.map(item => {
          const Icon = item.icon;
          const active =
            screen === item.screen;

          return (
            <button
              key={item.screen}
              onClick={() =>
                setScreen(
                  item.screen
                )
              }
              className={`flex flex-col items-center gap-1 py-2 text-xs ${
                active
                  ? "font-bold text-blue-600"
                  : "text-gray-500"
              }`}
            >
              <Icon size={20} />
              {item.label}
            </button>
          );
        })}
      </div>
    </nav>
  );
}

function HomePage({
  user
}: {
  user: User;
}) {
  return (
    <main className="mx-auto max-w-3xl px-3 py-5 pb-24 sm:px-6">
      <CreatePost user={user} />
      <Feed user={user} />
    </main>
  );
}

function MenuPage({
  user,
  dark,
  toggleDark
}: {
  user: User;
  dark: boolean;
  toggleDark: () => void;
}) {
  return (
    <main className="mx-auto max-w-3xl px-4 py-6 pb-24">
      <h1 className="text-2xl font-black">
        Menu
      </h1>

      <div className="mt-5 space-y-2">
        <button
          onClick={toggleDark}
          className="flex w-full items-center gap-3 rounded-2xl bg-white p-4 text-left dark:bg-gray-900"
        >
          {dark ? (
            <Sun size={21} />
          ) : (
            <Moon size={21} />
          )}
          {dark
            ? "Light mode"
            : "Dark mode"}
        </button>

        <button
          onClick={() =>
            logoutUser()
          }
          className="flex w-full items-center gap-3 rounded-2xl bg-white p-4 text-left text-red-600 dark:bg-gray-900"
        >
          <LogOut size={21} />
          Logout
        </button>
      </div>
    </main>
  );
}